<template>
    <div class="welcome">
        <div class="main-wel">
            welcome to kettle
        </div>
    </div>
</template>
<script>
    export default {
        name: 'welcome',
        data () {
            return {

            };
        },
        methods: {
        }
    };
</script>

<style lang="less" scoped>
    .welcome{
        background-color: white;
        height: 100%;
        border-top: 10px solid #5e6a9e;
        width: 1663px;
        *width:100%;
    }
</style>
